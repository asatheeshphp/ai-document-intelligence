import axios from "axios";
import { z } from "zod";
import { env } from "@/config/env";

const InvoiceExtractionSchema = z.object({
  invoiceNumber: z.string().nullable().optional(),
  vendorName: z.string().nullable().optional(),
  invoiceDate: z.string().nullable().optional(),
  currency: z.string().nullable().optional(),
  totalAmount: z.number().nullable().optional(),
});

export type InvoiceExtractionResult = z.infer<typeof InvoiceExtractionSchema>;

export class OllamaService {
  async extractInvoiceData(
    documentText: string,
    model: string = env.OLLAMA_CHAT_MODEL
  ): Promise<InvoiceExtractionResult> {
    const baseUrl = env.OLLAMA_BASE_URL.replace(/\/$/, "");

    const prompt = `You are extracting invoice data from raw text. Return ONLY valid JSON with these fields: invoiceNumber, vendorName, invoiceDate, currency, totalAmount. If a value is unknown, use null.\n\nDocument text:\n${documentText}`;

    const response = await axios.post(
      `${baseUrl}/api/chat`,
      {
        model,
        stream: false,
        messages: [{ role: "user", content: prompt }],
      },
      {
        timeout: 120000,
      }
    );

    const content = response.data?.message?.content ?? "{}";
    const match = content.match(/\{[\s\S]*\}/);
    const jsonText = match ? match[0] : content;
    const parsed = JSON.parse(jsonText);

    return InvoiceExtractionSchema.parse(parsed);
  }

  async embedText(text: string, model: string = env.OLLAMA_EMBED_MODEL): Promise<number[]> {
    const baseUrl = env.OLLAMA_BASE_URL.replace(/\/$/, "");

    const response = await axios.post(
      `${baseUrl}/api/embeddings`,
      {
        model,
        prompt: text,
      },
      {
        timeout: 120000,
      }
    );

    return response.data?.embedding ?? [];
  }
}
