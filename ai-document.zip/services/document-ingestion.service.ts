import fs from "node:fs/promises";
import path from "node:path";
import pdfParse from "pdf-parse";
import { ProcessingRepository } from "@/repositories/processing.repository";
import { OllamaService } from "@/services/ollama.service";
import { OcrService } from "@/services/ocr.service";

export interface ProcessLocalDocumentInput {
  sourcePath: string;
  filename?: string;
  metadata?: Record<string, unknown>;
}

export class DocumentIngestionService {
  constructor(
    private readonly repository: ProcessingRepository = new ProcessingRepository(),
    private readonly ollamaService: OllamaService = new OllamaService()
  ) {}

  async processLocalDocument(input: ProcessLocalDocumentInput) {
    const absolutePath = path.resolve(input.sourcePath);
    const fileBuffer = await fs.readFile(absolutePath);
    const fileSize = fileBuffer.length;
    const fileName = path.basename(absolutePath);

    let text = "";
    let extractedText: string | undefined;
    let numPages: number | null = null;
    let extractionDurationMs = 0;
    let requiresOcr = false;
    let pdfExtractionError: string | null = null;

    if (absolutePath.toLowerCase().endsWith(".pdf")) {
      try {
        const startTime = Date.now();
        // pdf-parse returns an object with a `text` field containing extracted text
        // the imported module may be a function or namespace depending on bundler, cast to any
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const pdfResult = await (pdfParse as any)(fileBuffer);
        extractionDurationMs = Date.now() - startTime;

        const rawText = String(pdfResult?.text ?? "");
        const normalizedText = rawText.trim();
        const pagesFromResult = typeof pdfResult?.numpages === "number"
          ? pdfResult.numpages
          : typeof pdfResult?.info?.Pages === "number"
          ? pdfResult.info.Pages
          : null;
        numPages = pagesFromResult;

        if (!normalizedText) {
          requiresOcr = true;
          pdfExtractionError = "PDF contained no extractable text.";
          console.info(JSON.stringify({
            event: "pdf-extraction",
            filename: fileName,
            fileSize,
            numPages,
            extractedCharacters: 0,
            preview: "",
            durationMs: extractionDurationMs,
            status: "OCR_REQUIRED",
          }));
        } else {
          text = normalizedText;
          extractedText = normalizedText;
          console.info(JSON.stringify({
            event: "pdf-extraction",
            filename: fileName,
            fileSize,
            numPages,
            extractedCharacters: normalizedText.length,
            preview: normalizedText.slice(0, 500),
            durationMs: extractionDurationMs,
            status: "SUCCEEDED",
          }));
        }
      } catch (err) {
        extractionDurationMs = Date.now() - extractionDurationMs;
        requiresOcr = true;
        pdfExtractionError = err instanceof Error ? err.message : "Unknown PDF extraction error.";
        console.error(JSON.stringify({
          event: "pdf-extraction-failed",
          filename: fileName,
          fileSize,
          numPages,
          extractedCharacters: 0,
          preview: "",
          durationMs: extractionDurationMs,
          status: "OCR_REQUIRED",
          error: pdfExtractionError,
        }));
      }
    } else {
      text = fileBuffer.toString("utf-8");
      extractedText = text.trim();
    }

    let ocrSucceeded = false;
    let ocrAvailable = false;

    // If extracted text is too short, attempt OCR fallback
    if (text.trim().length < 200) {
      const ocr = new OcrService();
      try {
        const ocrText = await ocr.ocrPdf(absolutePath);
        ocrAvailable = true;
        if (ocrText && ocrText.trim().length > text.trim().length) {
          text = ocrText;
          ocrSucceeded = true;
        }
      } catch (err) {
        // log and continue with whatever text we have; if OCR is unavailable then mark document for OCR later
        // eslint-disable-next-line no-console
        console.warn("OCR fallback failed:", err instanceof Error ? err.message : err);
      }
    }

    const email = await this.repository.createEmail({
      messageId: `local-${Date.now()}`,
      senderAddress: "local-source@example.com",
      subject: `Local document import: ${input.filename ?? path.basename(absolutePath)}`,
      metadata: { sourcePath: absolutePath, ...(input.metadata ?? {}) },
    });

    const document = await this.repository.createDocument({
      emailId: email._id,
      filename: input.filename ?? path.basename(absolutePath),
      documentType: "INVOICE",
      status: "EXTRACTING",
      extractedText: text,
      metadata: { sourcePath: absolutePath, ...(input.metadata ?? {}) },
    });

    if (text.trim().length < 200 && !ocrSucceeded) {
      await this.repository.updateDocumentStatus(document._id, "OCR_REQUIRED", {
        lastError: "OCR is required for this document. Install OCR tooling or use a text-searchable PDF.",
      });

      return {
        email,
        document,
        extraction: null,
        invoice: null,
        message: "OCR is required for this document.",
      };
    }

    const extractionResult = await this.ollamaService.extractInvoiceData(text);

    const extraction = await this.repository.createExtraction({
      documentId: document._id,
      status: "SUCCEEDED",
      attempts: 1,
      modelName: "qwen2.5:1.5b",
      structuredData: extractionResult,
      metadata: { source: "local-folder" },
    });

    const invoice = await this.repository.createInvoice({
      documentId: document._id,
      invoiceNumber: extractionResult.invoiceNumber ?? undefined,
      vendorName: extractionResult.vendorName ?? undefined,
      invoiceDate: extractionResult.invoiceDate ? new Date(extractionResult.invoiceDate) : undefined,
      currency: extractionResult.currency ?? undefined,
      totalAmount: extractionResult.totalAmount ?? undefined,
      status: "EXTRACTED",
      extractedData: extractionResult,
      metadata: { source: "local-folder" },
    });

    // Chunk the extracted text for chunk-level embeddings
    const chunks = this.chunkText(text);

    for (const c of chunks) {
      const chunkDoc = await this.repository.createChunk({
        invoiceId: invoice._id,
        documentId: document._id,
        chunkType: c.type,
        text: c.text,
        startOffset: c.start,
        endOffset: c.end,
        tokenCount: c.tokenCount,
        metadata: { source: "local-folder" },
      });

      const vector = await this.ollamaService.embedText(c.text);

      await this.repository.createEmbedding({
        invoiceId: invoice._id,
        documentId: document._id,
        chunkId: chunkDoc._id,
        chunkType: c.type,
        embeddingModel: "nomic-embed-text",
        embeddingVector: vector,
        status: "COMPLETED",
        metadata: { source: "local-folder" },
      });
    }

    await this.repository.updateDocumentStatus(document._id, "EXTRACTED", {
      extractedText: text,
    });

    return {
      email,
      document,
      extraction,
      invoice,
    };
  }

  private async generateEmbeddingVector(text: string): Promise<number[]> {
    const response = await this.ollamaService.embedText(text);
    return response;
  }

  private chunkText(text: string) {
    // naive chunker: look for headings; otherwise split into 4 roughly equal chunks
    const normalized = text.replace(/\r\n/g, "\n").trim();
    const lines = normalized.split("\n").map((l) => l.trim()).filter(Boolean);

    // try simple heuristics for header, line items, totals, footer
    const headerLines: string[] = [];
    const lineItemsLines: string[] = [];
    const paymentLines: string[] = [];
    const notesLines: string[] = [];

    let mode: "header" | "items" | "payment" | "notes" = "header";

    for (const line of lines) {
      const lower = line.toLowerCase();
      if (lower.includes("invoice") || lower.includes("invoice number") || lower.includes("date") || lower.includes("vendor") ) {
        mode = "header";
      } else if (lower.includes("total") || lower.includes("subtotal") || lower.includes("tax") || lower.includes("amount")) {
        mode = "payment";
      } else if (lower.includes("item") || lower.match(/\d+\s+pcs|qty|unit/)) {
        mode = "items";
      } else if (lower.includes("note") || lower.includes("terms") || lower.includes("remarks")) {
        mode = "notes";
      }

      if (mode === "header") headerLines.push(line);
      else if (mode === "items") lineItemsLines.push(line);
      else if (mode === "payment") paymentLines.push(line);
      else notesLines.push(line);
    }

    const chunks: Array<{ type: string; text: string; start: number; end: number; tokenCount: number }> = [];
    let offset = 0;

    const pushChunk = (type: string, arr: string[]) => {
      if (arr.length === 0) return;
      const t = arr.join("\n");
      const start = offset;
      const end = offset + t.length;
      const tokenCount = t.split(/\s+/).length;
      chunks.push({ type, text: t, start, end, tokenCount });
      offset = end + 1;
    };

    pushChunk("header", headerLines);
    pushChunk("line_items", lineItemsLines);
    pushChunk("payment", paymentLines);
    pushChunk("notes", notesLines);

    // If no chunks produced (very short or weird layout), split into 1 chunk
    if (chunks.length === 0) {
      const t = normalized;
      chunks.push({ type: "other", text: t, start: 0, end: t.length, tokenCount: t.split(/\s+/).length });
    }

    return chunks;
  }
}
