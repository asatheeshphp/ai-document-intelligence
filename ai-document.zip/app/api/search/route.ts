import { NextResponse } from "next/server";
import { VectorRepository } from "@/repositories/vector.repository";
import { ProcessingRepository } from "@/repositories/processing.repository";
import { OllamaService } from "@/services/ollama.service";
import { cosineDistance } from "@/utils/vector";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const query = body?.query as string | undefined;
    if (!query) {
      return NextResponse.json({ success: false, error: "query is required" }, { status: 400 });
    }

    const ollama = new OllamaService();
    const queryVector = await ollama.embedText(query);

    const vectorRepo = new VectorRepository();
    const allEmbeddings = await vectorRepo.findAllEmbeddings();

    if (allEmbeddings.length === 0) {
      return NextResponse.json({ success: false, error: "No embeddings available for search" }, { status: 404 });
    }

    const scored = allEmbeddings
      .filter((embedding) => Array.isArray(embedding.embeddingVector) && embedding.embeddingVector.length > 0)
      .map((embedding) => ({
        embedding,
        score: cosineDistance(queryVector, embedding.embeddingVector),
      }))
      .sort((a, b) => a.score - b.score)
      .slice(0, 10);

    const invoiceIds = Array.from(new Set(scored.map((item) => item.embedding.invoiceId.toString())));
    const invoiceResults = await new ProcessingRepository().findInvoicesByIds(invoiceIds);

    return NextResponse.json({
      success: true,
      query,
      results: scored.map((item) => ({
        invoiceId: item.embedding.invoiceId.toString(),
        documentId: item.embedding.documentId.toString(),
        chunkId: item.embedding.chunkId?.toString(),
        chunkType: item.embedding.chunkType,
        score: item.score,
      })),
      invoices: invoiceResults,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown search error",
      },
      { status: 500 }
    );
  }
}
