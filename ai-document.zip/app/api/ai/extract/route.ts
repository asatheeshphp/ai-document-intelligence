import { NextResponse } from "next/server";
import { ProcessingRepository } from "@/repositories/processing.repository";
import { OllamaService } from "@/services/ollama.service";

export async function GET() {
  return NextResponse.json(
    {
      success: false,
      error: "Use POST with a JSON body containing documentId to run AI extraction.",
    },
    { status: 405 }
  );
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const documentId = body?.documentId as string | undefined;

    if (!documentId) {
      return NextResponse.json(
        { success: false, error: "documentId is required" },
        { status: 400 }
      );
    }

    const repository = new ProcessingRepository();
    const document = await repository.findDocumentById(documentId);

    if (!document) {
      return NextResponse.json(
        { success: false, error: "Document not found" },
        { status: 404 }
      );
    }

    const textToExtract = document.extractedText ?? "Invoice details are unavailable.";
    const ollama = new OllamaService();
    const result = await ollama.extractInvoiceData(textToExtract);

    const extraction = await repository.createExtraction({
      documentId: document._id,
      status: "SUCCEEDED",
      attempts: 1,
      modelName: "qwen2.5:1.5b",
      structuredData: result,
      metadata: { source: "ai-extraction" },
    });

    await repository.updateDocumentStatus(document._id, "EXTRACTED", {
      extractedText: textToExtract,
    });

    return NextResponse.json({
      success: true,
      documentId: document._id.toString(),
      extractionId: extraction._id.toString(),
      result,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown AI extraction error",
      },
      { status: 500 }
    );
  }
}
